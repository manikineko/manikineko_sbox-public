﻿using Sandbox;
using Sandbox.UI;
using Sandbox.UI.Construct;
using System;

public class Health : Panel
{
	public Label Label;
	

	public Health()
	{
		//AmmoLabel = Add.Label( "NaN", "ammovalue" );
		Label = Add.Label( "NaN", "value" );


	}

	public override void Tick()
	{
		var player = Game.LocalPawn;
		if ( player == null ) return;
		string HPChar = "❤️";
		string HPChars = "";


		if ( player.Health.CeilToInt() != 0 )
		{
			Label.Style.FontSize = int.Clamp( player.Health.CeilToInt(), 10, 50 );

			/*
			int procentage = (int)Math.Round( int.Clamp(player.Health.CeilToInt(),0,100) * 100 / 100f );
			LabelAmmount.Text = procentage + "% HP";
		int Heartcount = int.Clamp( player.Health.CeilToInt(), 0, 100 );
		if ( HPChars.Length !=  Heartcount )
		{
			for ( int i = 0; i < Heartcount; i++ )
			{
				HPChars += HPChar;
			}
		}
			*/

			Label.Style.Display = DisplayMode.Flex;
		}
		else
		{
		}
		if(player.Health > 0)
		Label.Text = $"{player.Health} HP";
	}

}
