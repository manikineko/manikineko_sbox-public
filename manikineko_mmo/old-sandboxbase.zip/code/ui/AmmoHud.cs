﻿using Sandbox;
using Sandbox.UI;
using Sandbox.UI.Construct;
using System;

public class AmmoHud : Panel
{
	public Label AmmoLabel;
	static float Ammop;
	static float Reloads;
	public AmmoHud()
	{
		Ammop = 0F;
		Reloads = 0F;
		AmmoLabel = Add.Label( "NaN", "ammovalue" );
		

	}
	public static void SetAmmo(float ammount )
	{
		Ammop = ammount;
	}
	public static void SetReloads(float ammount )
	{
		Reloads = ammount;
	}
	public override void Tick()
	{
		var player = Game.LocalPawn;
		if ( player == null ) return;
		if ( Ammop > 0 | Reloads > 0 )
		{
			AmmoLabel.Text = $"{Ammop} / {Reloads} Ammo";
			AmmoLabel.Style.FontSize = float.Clamp( 50 - Ammop, 10, 50 );
			AmmoLabel.Style.Display = DisplayMode.Flex;

		}
		else
		{
			AmmoLabel.Style.Display = DisplayMode.None;
		}

	}
}
